"use strict";
// elements references
const productsContainer = document.getElementById("productsContainer");
const cartContainer = document.getElementById("cartContainer");
const feedback = document.getElementById("feedback");
const clearcartbtn = document.getElementById("clearCart");
const sortByPriceBtn = document.getElementById("sortByPrice");

// default products
const products = [
  { id: 1, name: "Laptop", price: 50000 },
  { id: 2, name: "Phone", price: 2000 },
  { id: 3, name: "Tab", price: 5000 },
  { id: 4, name: "Smartwatch", price: 1000 },
  { id: 5, name: "Headphone", price: 500 },
  { id: 6, name: "Shoes", price: 3000 },
  { id: 7, name: "Jacket", price: 1200 },
  //{ id: 8, name: "Bed", price: 30000 },
];
// empty cart
const cart = [];

let timerId;

function renderCartDetails() {
  cartContainer.innerHTML = "";
  cart.forEach(function (product) {
    const { id, name, price } = product;

    const cartItemRow = `<div class="product-row">
                    <p>${name} Rs.${price}</p>
                    <button onclick="removeFromCart(${id})">Remove</button>
                </div>`;

    cartContainer.insertAdjacentHTML("beforeend", cartItemRow);
  });

  //let totalPrice = 0;

  // for (let i = 0; i < cart.length; i++) {
  //   totalPrice = totalPrice + cart[i].price;
  // }

  const totalPrice = cart.reduce(function (preval, curProduct) {
    return preval + curProduct.price;
  }, 0);

  document.getElementById("totalPrice").textContent = `Rs.(${totalPrice})`;
}
function renderProductDetails() {
  products.forEach(function (product) {
    // // we have to implement dynamically   <div class="product-row">
    //                   <p>Laptop Rs.50000</p>
    //                   <button>Add to card</button>
    //               </div>
    ///-----------method one --------------
    // const productRow = ` <div class="product-row">
    //                   <p>${product.name} Rs. ${product.price}</p>
    //                   <button>Add to card</button>
    //               </div>`;
    // productsContainer.insertAdjacentHTML("beforeend", productRow);
    //--------------method 2---------------
    const { id, name, price } = product;
    const divElement = document.createElement("div");
    divElement.className = "product-row";
    divElement.innerHTML = `<p>${name} Rs. ${price}</p>
                    <button onclick="addToCart(${id})">Add to cart</button>`;

    productsContainer.appendChild(divElement);
  });
}

function addToCart(id) {
  // console.log("clicked on add to cart", id);
  // check if item alredy present or not
  const productsToAdd = products.find((product) => product.id === id);
  const isProductAvailable = cart.some((product) => product.id === id);

  if (isProductAvailable) {
    updateUserfeedback(`Item is already added to the cart.`, "error");
    return;
  }

  cart.push(productsToAdd);
  renderCartDetails();

  console.log(cart);

  updateUserfeedback(`${productsToAdd.name} is added to the cart.`, "success");
}

function removeFromCart(id) {
  console.log(id);
  const product = cart.find((product) => product.id === id);
  // const updatedCart = cart.filter(function (product) {
  //   return product.id !== id;
  // });
  const productIndex = cart.findIndex((product) => product.id === id);
  cart.splice(productIndex, 1);

  // console.log(updatedCart);
  // cart = updatedCart;

  updateUserfeedback(`${product.name} is removed from cart.`, "error");
  renderCartDetails();
}

function updateUserfeedback(msg, type) {
  clearTimeout(timerId);
  feedback.style.display = "block";
  // type -- sucess= green and error red for coloring

  if (type === "success") {
    feedback.style.backgroundColor = "green";
  }
  if (type === "error") {
    feedback.style.backgroundColor = "red";
  }
  feedback.textContent = msg;

  timerId = setTimeout(function () {
    feedback.style.display = "none";
  }, 2000);
}

function clearCart() {
  console.log("cleared cart");
  cart.length = 0;
  renderCartDetails();
  updateUserfeedback(`cart is cleared`, "success");
}

function sortByPrice() {
  cart.sort((item1, item2) => item1.price - item2.price);
  updateUserfeedback(`cart was sorted by prices`, "success");
  renderCartDetails();
}
clearcartbtn.addEventListener("click", clearCart);

sortByPriceBtn.addEventListener("click", sortByPrice);

renderProductDetails();
